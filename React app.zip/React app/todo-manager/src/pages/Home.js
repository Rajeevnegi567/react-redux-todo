import React from "react";
import TaskList from "../components/TaskList";

function Home() {
  return (
    <div>
      <TaskList />
    </div>
  );
}

export default Home;
