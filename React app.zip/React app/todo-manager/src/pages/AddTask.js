import React from "react";
import { useDispatch } from "react-redux";
import TaskForm from "../components/TaskForm";
import { addTask } from "../features/tasksSlice";

function AddTask() {
  const dispatch = useDispatch();

  const handleSubmit = (task) => {
    dispatch(addTask({ ...task, id: Date.now() }));
  };

  return (
    <div>
      <h2>Add New Task</h2>
      <TaskForm onSubmit={handleSubmit} />
    </div>
  );
}

export default AddTask;
