import React from "react";
import { useParams } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import TaskForm from "../components/TaskForm";
import { updateTask } from "../features/tasksSlice";

function EditTask() {
  const { id } = useParams();
  const task = useSelector((state) =>
    state.tasks.tasks.find((task) => task.id === parseInt(id))
  );
  const dispatch = useDispatch();

  const handleSubmit = (updatedTask) => {
    dispatch(updateTask(updatedTask));
  };

  return (
    <div>
      <h2>Edit Task</h2>
      <TaskForm task={task} onSubmit={handleSubmit} />
    </div>
  );
}

export default EditTask;
